﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using OpenTK.Input;
using System.Windows.Forms;
using System.IO;
using SharpDX.XAudio2;
using SharpDX.Multimedia;
using SharpDX.IO;

namespace SphereDivision
{
	/*
	Features to add:
	quad faces
	face colors for different tri types
	sounds based on face area, alternative to line length
	Auto-show? (automatically randomly change settings)
	dividing a hypersphere(4d, 5d?)
	*/

	class Game : GameWindow
	{
		float viewScale = 1f;
		bool showVerts = true;
		float zWall;
		bool wireFrame = true;
		bool showBacks = true;
		bool showHelp = false;
		float lineThickness = 4f;
		float binocSplit = 500f;
		bool rotateNow = true; //rotates visualization if true
		float spinAngle = 0f; //updated each tick to rotate visualization
		float spinAngleY = 0f;
		bool fixedTop = false; //when true, point zero is fixed to the top of the sphere
		int lockedVerts = 0; // if > 0 then any verts up to this index get locked in position, this is for attempting to subdivide
		int findFaces = 1; //when 1 tries to find triangular faces, 2 shows flower view, 0 no faces rendered
		bool binocular = false; //when true, renders crosseyed 3d view
		bool haltGrav = false; //when true, stops trying to move points around until next reset
		bool inputMode = false;
		string inputVal;
		bool exitQuestion = false;
		bool hideMessage = false;

		enum LineTolerance //whether to draw secondary and tertiary lines for longer distances between verts
		{
			primaryOnly = 0,
			Secondary = 1,
			Tertiary = 2
		}
		LineTolerance lineLevel = LineTolerance.Tertiary;

		// my vars
		Random random = new Random();
		int maxDots = 32;
		Vector3[] p = new Vector3[32768]; //positions of verts
		Vector3[] v = new Vector3[32768]; //velocities when they are being moved
		Vector3[] pLocked = new Vector3[32768]; //positions of locked vertices, so they don't get erased accidentally
		int[] triListA; //for face detection
		int[] triListB;
		int[] triListC;
		float[] triArea;
		int triCount;
		//int[] pEdges;
		int numEdges = 0;
		long lastTime, curTime, deltaTime; //milliseconds = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
		int tempTicks; //number of ticks per loop
		int fps; //for counting how many frames are rendered each second
		int fpsCount; //to be displayed, updated once per second
		long fpsTime;
		float minDist;
		float sphereRadius = 750f;
		float gravConst = 25000f;
		bool toleranceReached = false;
		Vector3[] lastp = new Vector3[32768]; //for comparing positions this time to last time
		Vector3[] empty = new Vector3[32768]; //for emptying out an array by filling it with zeros
		long tickCount = 0;
		
		bool autoSearch = false; // when set to true, will go through looking for divisible numbers by taking creenshots of several resets
		int autoSearchIteration = 0;
		Vector2 lastMousePos = new Vector2();
		bool lastButtonState = false; //previous mouse button state so we can tell when it's first pressed
		int lastWheel;
		KeyboardState keyboard, lastkeyboard;
		bool[] keysHeld = new bool[5]; //set to true when this key is to be activated by timer
		int[] keyTimers = new int[5]; //tracks how long since last keypress
		enum keysUsed
		{
			Right, Left, PageUp, PageDown, Enter
		}

		float[][][] helpMessage = new float[40][][];
		float[][] displayString = new float[256][]; //lists of verts to be turned into lines by opengl
		int messageLength = 0;
		int messageTime = 0; //how long to display this message, if -100000 just display forever
		float[][] charVector = new float[96][]; //the font itself
		Vector3[] circle = new Vector3[8]; //for drawing a little "circle" around a locked vertex
 

		//sound stuff
		XAudio2 xaudio;
		WaveFormat waveFormat;
		AudioBuffer buffer;
		SoundStream soundstream;
		SourceVoice[] sourceVoice;
		int soundOn = 0;
		int currentVoice = 0;
		int voiceLoop = 0;

		public Game()
			: base(1920, 1080, new OpenTK.Graphics.GraphicsMode(32, 24, 0, 4))
		{

		}

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);

			//for 4d testing:
			//binocular = false;
			//findFaces = 0;
			//lineLevel = 0;

			if (autoSearch) //this is only true if you set it in the var declaration.
			{
				maxDots = 4;
				binocular = true;
				lineLevel = LineTolerance.primaryOnly;
			}
			//this.Cursor = OpenTK.MouseCursor.Cross;
			initAudio();
			getFonts();
			createMessage("simulation INITIALIZED  --  PRESS F1 FOR HELP", -1000f, 800f, 3, 5000);
			initHelpMessage();
			zWall = sphereRadius;
			//initProgram();
			// hide max,min and close button at top right of Window
			//FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			// fill the screen

			initSphere();

			this.WindowBorder = WindowBorder.Hidden;
			Bounds = System.Windows.Forms.Screen.PrimaryScreen.Bounds;
			Title = "Sphere Division";
			GL.ClearColor(System.Drawing.Color.CornflowerBlue);
			GL.PointSize(5f);
		}

		void initAudio()
		{
			xaudio = new XAudio2();
			MasteringVoice masteringsound = new MasteringVoice(xaudio);
			NativeFileStream nativefilestream = new NativeFileStream(@"ding.wav", NativeFileMode.Open, NativeFileAccess.Read, NativeFileShare.Read);

			soundstream = new SoundStream(nativefilestream);
			waveFormat = soundstream.Format;
			buffer = new AudioBuffer
			{
				Stream = soundstream.ToDataStream(),
				AudioBytes = (int)soundstream.Length,
				Flags = BufferFlags.EndOfStream
			};

			sourceVoice = new SourceVoice[32];
			for (int i = 0; i < sourceVoice.Length; i++)
			{
				sourceVoice[i] = new SourceVoice(xaudio, waveFormat, VoiceFlags.None, 4f);
			}
			
		}

		void getFonts()
		{
			charVector[1] = new float[] { 6, 6, 9, 9, 6, 12, 9, 9, -1, 9 };
			charVector[2] = new float[] { 3, 6, 0, 9, 3, 12, 0, 9, 10, 9 };
			charVector[30] = new float[] { 10, 8, 8, 6, 4, 6, 2, 8, 2, 12, 4, 14, 8, 14, 10, 12, 12, 13, 12, 7, 9, 4, 3, 4, 0, 7, 0, 13, 3, 16, 9, 16, 12, 13 };
			charVector[31] = new float[] { 6, 10, 8, 16, 10, 19, 7, 19, 6, 18, 5, 18, 4, 19, 1, 19, 3, 16, 5, 10 };
			charVector[32] = new float[] { 10, 19 };
			charVector[33] = new float[] { 3, 16, 6, 16, 6, 19, 3, 19, 3, 14, 0, 0, 9, 0, 5, 16 };
			charVector[37] = new float[] { 4, 5, 1, 5, 1, 2, 4, 2, 5, 7, 9, 0, 0, 19, 4, 12, 5, 17, 8, 17, 8, 14, 4, 14 };
			charVector[38] = new float[] { 9, 19, 0, 6, 0, 4, 2, 2, 4, 2, 6, 4, 6, 6, 0, 12, 0, 16, 3, 19, 6, 19, 9, 12 };
			charVector[39] = new float[] { 4, 3, 1, 3, 1, 0, 4, 0, 4, 3, 3, 5, 0, 6 };
			charVector[40] = new float[] { 4, 0, 2, 2, 0, 7, 0, 12, 2, 17, 4, 19 };
			charVector[41] = new float[] { 0, 0, 2, 2, 4, 7, 4, 12, 2, 17, 0, 19 };
			charVector[43] = new float[] { 1, 9, 5, 9, 5, 13, 5, 4, 5, 9, 9, 9 };
			charVector[44] = new float[] { 4, 19, 1, 19, 1, 16, 4, 16, 4, 19, 1, 23 };
			charVector[45] = new float[] { 1, 9, 9, 9 };
			charVector[46] = new float[] { 2, 19, 2, 15, 6, 15, 6, 19, 2, 19 };
			charVector[47] = new float[] { 9, 0, 0, 19 };
			charVector[48] = new float[] { 9, 3, 9, 16, 6, 19, 3, 19, 0, 16, 0, 3, 3, 0, 6, 0, 8, 2, 1, 18 };
			charVector[49] = new float[] { 0, 19, 8, 19, 4, 19, 4, 0, 1, 7 };
			charVector[50] = new float[] { 0, 6, 0, 2, 2, 0, 7, 0, 9, 2, 9, 8, 0, 14, 0, 19, 10, 19 };
			charVector[51] = new float[] { 0, 2, 2, 0, 7, 0, 9, 2, 9, 8, 7, 10, 1, 10, 7, 10, 9, 12, 9, 17, 7, 19, 2, 19, -1, 16 };
			charVector[52] = new float[] { 7, 19, 7, 0, 0, 10, 10, 10 };
			charVector[53] = new float[] { 9, 0, 0, 0, 0, 9, 6, 9, 9, 12, 9, 16, 6, 19, 2, 19, -1, 16 };
			charVector[54] = new float[] { 9, 2, 7, 0, 2, 0, 0, 2, 0, 17, 2, 19, 7, 19, 9, 17, 9, 11, 7, 9, 0, 9 };
			charVector[55] = new float[] { 0, 0, 9, 0, 3, 20 };
			charVector[56] = new float[] { 0, 2, 2, 0, 7, 0, 9, 2, 9, 7, 7, 9, 2, 9, 0, 11, 0, 17, 2, 19, 7, 19, 9, 17, 9, 11, 7, 9, 2, 9, 0, 7, 0, 2 };
			charVector[57] = new float[] { 0, 17, 2, 19, 7, 19, 9, 17, 9, 2, 7, 0, 2, 0, 0, 2, 0, 8, 2, 10, 9, 10 };
			charVector[58] = new float[] { 3, 7, 3, 4, 6, 4, 6, 7, 3, 7, 3, 11, 3, 14, 6, 14, 6, 11, 3, 11 };
			charVector[60] = new float[] { 9, 0, 0, 9, 0, 10, 9, 19 };
			charVector[61] = new float[] { 9, 11, 1, 11, 1, 7, 9, 7 };
			charVector[62] = new float[] { 0, 0, 9, 9, 9, 10, 0, 19 };
			charVector[63] = new float[] { 6, 17, 4, 17, 4, 19, 6, 19, 5, 11, 9, 6, 9, 2, 7, 0, 2, 0, 0, 2, 0, 7 };
			charVector[64] = new float[] { 1, 8, 0, 7, 0, 2, 2, 0, 6, 0, 8, 2, 8, 7, 6, 9, 2, 9, 2, 2, 6, 2, 6, 5, 2, 5, 4, 5, 6, 9 };
			charVector[65] = new float[] { 0, 19, 5, 0, 10, 19, 8, 10, 2, 10 };
			charVector[66] = new float[] { 0, 19, 0, 0, 6, 0, 9, 3, 9, 6, 6, 9, 0, 9, 6, 9, 9, 12, 9, 16, 6, 19, 0, 19 };
			charVector[67] = new float[] { 9, 2, 7, 0, 3, 0, 0, 3, 0, 16, 3, 19, 7, 19, 10, 16 };
			charVector[68] = new float[] { 0, 0, 0, 19, 6, 19, 9, 16, 9, 3, 6, 0, 0, 0 };
			charVector[69] = new float[] { 9, 0, 0, 0, 0, 10, 6, 10, 0, 10, 0, 19, 10, 19 };
			charVector[70] = new float[] { 9, 0, 0, 0, 0, 9, 6, 10, 0, 10, 0, 20 };
			charVector[71] = new float[] { 9, 3, 6, 0, 3, 0, 0, 3, 0, 16, 3, 19, 6, 19, 9, 16, 9, 10, 4, 10 };
			charVector[72] = new float[] { 0, 0, 0, 19, 0, 10, 9, 10, 9, 19, 9, -1 };
			charVector[73] = new float[] { 0, 0, 8, 0, 4, 0, 4, 19, 0, 19, 9, 19 };
			charVector[74] = new float[] { 9, 0, 9, 16, 6, 19, 3, 19, 0, 16, 0, 13 };
			charVector[75] = new float[] { 0, 0, 0, 19, 0, 10, 9, 0, 0, 10, 10, 20 };
			charVector[76] = new float[] { 0, 0, 0, 19, 10, 19 };
			charVector[77] = new float[] { 0, 19, 0, 0, 4, 9, 5, 9, 9, 0, 9, 20 };
			charVector[78] = new float[] { 0, 19, 0, 0, 9, 19, 9, -1 };
			charVector[79] = new float[] { 3, 0, 6, 0, 9, 3, 9, 16, 6, 19, 3, 19, 0, 16, 0, 3, 3, 0 };
			charVector[80] = new float[] { 0, 19, 0, 0, 6, 0, 9, 3, 9, 7, 6, 10, 0, 10 };
			charVector[81] = new float[] { 9, 19, 8, 17, 6, 19, 3, 19, 0, 16, 0, 3, 3, 0, 6, 0, 9, 3, 9, 16, 7, 18, 4, 14 };
			charVector[82] = new float[] { 0, 19, 0, 0, 6, 0, 9, 3, 9, 7, 6, 10, 0, 10, 3, 10, 10, 20 };
			charVector[83] = new float[] { 9, 2, 7, 0, 2, 0, 0, 2, 0, 8, 2, 10, 7, 10, 9, 12, 9, 17, 7, 19, 2, 19, -1, 16 };
			charVector[84] = new float[] { 0, 0, 8, 0, 4, 0, 4, 20 };
			charVector[85] = new float[] { 0, 0, 0, 17, 2, 19, 7, 19, 9, 17, 9, -1 };
			charVector[86] = new float[] { 0, 0, 4, 19, 8, -1 };
			charVector[87] = new float[] { 0, 0, 0, 19, 4, 10, 5, 10, 9, 19, 9, -1 };
			charVector[88] = new float[] { 0, 0, 8, 19, 4, 10, 0, 19, 8, -1 };
			charVector[89] = new float[] { 0, 0, 4, 9, 4, 19, 4, 9, 8, -1 };
			charVector[90] = new float[] { 0, 0, 9, 0, 0, 19, 10, 19 };
			charVector[92] = new float[] { 0, 0, 9, 19 };
			charVector[95] = new float[] { 0, 19, 10, 19 };

			circle[0] = new Vector3(0f, -4f, 0f) * 2f;
			circle[1] = new Vector3(3f, -3f, 0f) * 2f;
			circle[2] = new Vector3(4f, 0f, 0f) * 2f;
			circle[3] = new Vector3(3f, 3f, 0f) * 2f;
			circle[4] = new Vector3(0f, 4f, 0f) * 2f;
			circle[5] = new Vector3(-3f, 3f, 0f) * 2f;
			circle[6] = new Vector3(-4f, 0f, 0f) * 2f;
			circle[7] = new Vector3(-3f, -3f, 0f) * 2f;
		}

		void renderHelpInstead()
		{
			GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
			float targetAspectRatio = (float)this.Width / this.Height; // 1.777
			GL.ClearColor(System.Drawing.Color.Black);
			GL.MatrixMode(MatrixMode.Projection);
			GL.PushMatrix();
			GL.LoadIdentity();
			float maxDepth = 1000f;
			if (maxDepth < 1000) maxDepth = 1000f;
			GL.Ortho(-1000 * targetAspectRatio , 1000 * targetAspectRatio, 1000 , -1000, maxDepth, -maxDepth);
			GL.MatrixMode(MatrixMode.Modelview);
			GL.PushMatrix();
			GL.LoadIdentity();
			GL.Enable(EnableCap.DepthTest);
			GL.Enable(EnableCap.LineSmooth);
			GL.Enable(EnableCap.Blend);

			GL.LineWidth(10f);
			GL.Enable(EnableCap.LineStipple);
			GL.LineStipple(1, 0x0101);

			GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.LineLoop);
			GL.Color3(0f, 1f, 0f);
			GL.Vertex3(-1000f * targetAspectRatio, -1000f, -997f);
			GL.Vertex3(1000f * targetAspectRatio, -1000f, -997f);
			GL.Vertex3(1000f * targetAspectRatio, 1000f, -997f);
			GL.Vertex3(-1000f * targetAspectRatio, 1000f, -997f);
			GL.End();

			GL.LineWidth(2f);
			GL.Disable(EnableCap.LineStipple);
			GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.Polygon);
			GL.Color3(0.1f, 0.1f, 0.1f);
			GL.Vertex3(-1000f * targetAspectRatio, -1000f, -996f);
			GL.Vertex3(1000f * targetAspectRatio, -1000f, -996f);
			GL.Vertex3(1000f * targetAspectRatio, 1000f, -996f);
			GL.Vertex3(-1000f * targetAspectRatio, -1000f, -996f);
			GL.Vertex3(-1000f * targetAspectRatio, 1000f, -996f);
			GL.Vertex3(1000f * targetAspectRatio, 1000f, -996f);
			GL.End();

			GL.Color3(0f, 1f, 0f);
			for (int txtLine = 0; txtLine < helpMessage.Length; txtLine++)
			{
				if (helpMessage[txtLine] != null)
				{
					for (int ch = 0; ch < helpMessage[txtLine].Length; ch++)
					{
						GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.LineStrip);
						for (int vert = 0; vert < helpMessage[txtLine][ch].Length; vert += 2)
						{
							GL.Vertex3(helpMessage[txtLine][ch][vert], helpMessage[txtLine][ch][vert + 1], -999.5f);
						}
						GL.End();

					}

				}
			}
			GL.Flush();
			SwapBuffers();
		}

		protected override void OnRenderFrame(FrameEventArgs e)
		{
			base.OnRenderFrame(e);


			//draw the help message if needed:
			if (showHelp)
			{
				renderHelpInstead();
				return;
			}

			if (soundOn>0) playSounds();

			curTime = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
			deltaTime = curTime - lastTime;
			fps++;
			fpsTime += deltaTime;
			if (fpsTime >= 1000)
			{
				fpsTime -= 1000;
				fpsCount = fps;
				fps = 0;
			}
			lastTime = curTime;

			GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

			//set up the viewport's drawing scale so that everything shows up
			//get the window's aspect ratio
			float targetAspectRatio = (float)this.Width / this.Height; // 1.777
			GL.ClearColor(System.Drawing.Color.Black);
			GL.MatrixMode(MatrixMode.Projection);
			GL.PushMatrix();
			GL.LoadIdentity();
			float maxDepth = 1000f * viewScale;
			if (maxDepth < 1000) maxDepth = 1000f;
			GL.Ortho(-1000 * targetAspectRatio * viewScale, 1000 * targetAspectRatio * viewScale, 1000 * viewScale, -1000 * viewScale, maxDepth, -maxDepth);
			GL.MatrixMode(MatrixMode.Modelview);
			GL.PushMatrix();
			GL.LoadIdentity();
			GL.Enable(EnableCap.DepthTest);
			GL.Enable(EnableCap.LineSmooth);
			GL.Enable(EnableCap.Blend);
			//GL.Enable(EnableCap.AlphaTest);
			//GL.LineStipple(1, 0x0101);

			if (zWall < sphereRadius )
			{
				GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.Polygon);
				GL.Color3(0.1f, 0.1f, 0.1f);
				GL.Vertex3(-1000f * targetAspectRatio, -1000f, zWall);
				GL.Vertex3(1000f * targetAspectRatio, -1000f, zWall);
				GL.Vertex3(1000f * targetAspectRatio, 1000f, zWall);
				GL.Vertex3(-1000f * targetAspectRatio, -1000f, zWall);
				GL.Vertex3(-1000f * targetAspectRatio, 1000f, zWall);
				GL.Vertex3(1000f * targetAspectRatio, 1000f, zWall);
				GL.End();
				GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.LineLoop);

				GL.Color3(0f, 0f, 1f);
				GL.Vertex3(-1000f * targetAspectRatio, -1000f, -997f);
				GL.Vertex3(1000f * targetAspectRatio, -1000f, -997f);
				GL.Vertex3(1000f * targetAspectRatio, 1000f, -997f);
				GL.Vertex3(-1000f * targetAspectRatio, 1000f,-997f);
				GL.End();
			}

			//handle all the rotation into temp vertices
			if (rotateNow)
			{
				if ((deltaTime) < 100) spinAngle += (deltaTime / 4000f);
				else spinAngle += 0.001f;
			}
			while (spinAngle > 6.28f) { spinAngle -= 6.28f; }
			while (spinAngle < -6.28f) { spinAngle += 6.28f; }

			Vector3[] nd;
			if (spinAngleY != 0f)
			{
				while (spinAngleY > 6.28f)  { spinAngleY -= 6.28f; }
				while (spinAngleY < -6.28f) { spinAngleY += 6.28f; }
				float tCos = (float)Math.Cos(spinAngleY);
				float tSin = (float)Math.Sin(spinAngleY);
				nd = new Vector3[maxDots];
				for (var i = 0; i < maxDots; i++)
				{
					nd[i].Z = (p[i].Z * tCos) + (p[i].Y * tSin);
					nd[i].Y = (p[i].Y * tCos) - (p[i].Z * tSin);
					nd[i].X = p[i].X;
					
				}
				tCos = (float)Math.Cos(spinAngle);
				tSin = (float)Math.Sin(spinAngle);
				Vector3[] nd2 = new Vector3[maxDots];
				for (var i = 0; i < maxDots; i++)
				{
					nd2[i].X = (nd[i].X * tCos) - (nd[i].Z * tSin);
					nd2[i].Z = (nd[i].Z * tCos) + (nd[i].X * tSin);
					nd2[i].Y = nd[i].Y;
				}
				nd2.CopyTo(nd,0);
			}
			else
			{
				float tCos = (float)Math.Cos(spinAngle);
				float tSin = (float)Math.Sin(spinAngle);
				nd = new Vector3[maxDots];
				for (var i = 0; i < maxDots; i++)
				{
					nd[i].X = (p[i].X * tCos) - (p[i].Z * tSin);
					nd[i].Z = (p[i].Z * tCos) + (p[i].X * tSin);
					nd[i].Y = p[i].Y;
				}
			}
			//done rotating everything

			if (showBacks)
			{
				if (binocular)
				{
					float cx = binocSplit * targetAspectRatio * viewScale;
					drawVisualization(cx, nd, false);
					cx = -binocSplit * targetAspectRatio * viewScale;
					drawVisualization(cx, nd, true);
				}
				else
				{
					drawVisualizationCentered(nd);
				}
			}
			else
			{
				if (binocular)
				{
					float cx = binocSplit * targetAspectRatio * viewScale;
					drawFrontVisualization(cx, nd, false);
					cx = -binocSplit * targetAspectRatio * viewScale;
					drawFrontVisualization(cx, nd, true);
				}
				else
				{
					drawFrontVisualizationCentered(nd);
				}
			}

			
			//show whatever displaymessage there is:
			if (exitQuestion)
			{
				
				createMessage("Exit? Y/N", -220, -50, 4, -10000);
				if ((DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond) %1000 > 500)
				{ GL.Color3(1f, 1f, 1f); } else { GL.Color3(0f, 0f, 0f); }
				GL.LineWidth(4f);
				for (int i = 0; i < messageLength; i++)
				{
					GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.LineStrip);
					
					for (int j = 0; j < displayString[i].Length; j += 2)
					{
						GL.Vertex3(displayString[i][j], displayString[i][j + 1], -999.5f);
					}
					GL.End();
				}
				GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.Polygon);
				GL.Color3(0.4f, 0.4f, 0.4f);
				GL.Vertex3(-400, -200, -999.25f);
				GL.Vertex3(400f, -200f, -999.25f);
				GL.Vertex3(400f, 200f, -999.25f);
				GL.Vertex3(-400f, -200f, -999.25f);
				GL.Vertex3(-400f, 200f, -999.25f);
				GL.Vertex3(400f, 200f, -999.25f);
				GL.End();

				GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.LineLoop);
				GL.Color3(1f, 0f, 0f);
				GL.Vertex3(-400f, -200f, -997f);
				GL.Vertex3(400f, -200f, -997f);
				GL.Vertex3(400f, 200f, -997f);
				GL.Vertex3(-400f, 200f, -997f);
				GL.End();

			}
			else
			{
				if (!inputMode)
				{
					messageTime -= (int)(e.Time * 1000);
					if (messageTime < 0)
					{
						//message expired, go back to showing deltatime?
						string m = "";
						if (soundOn == 1) m += "<EDGE SOUNDS>";
						else if (soundOn == 2) m += "<FACE SOUNDS>";
						if (toleranceReached || haltGrav) m += " <HOLDING> ";
						if (findFaces==1) createMessage(m + fpsCount + " FPS " + tempTicks + " TICKS, " + numEdges + " EDGES, " + maxDots + " vertices, " + triCount + " faces  F1=HELP", -1000, 800, 2, 500);
						else createMessage(m + fpsCount + " FPS " + tempTicks + " TICKS, " + numEdges + " EDGES, " + maxDots + " vertices  F1=HELP", -1000, 800, 2, 500);
					}

				}
				if (!hideMessage || inputMode)
				{
					GL.LineWidth(2f);
					GL.Color3(1f, 1f, 0f);
					for (int i = 0; i < messageLength; i++)
					{
						GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.LineStrip);
						for (int j = 0; j < displayString[i].Length; j += 2)
						{
							GL.Vertex3(displayString[i][j], displayString[i][j + 1], -998f);
						}
						GL.End();
					}
				}
			}

			GL.Flush();
			SwapBuffers();
		}

		void drawVisualization(float xOffset, Vector3[] nd, bool crossProjection)
		{
			Vector3[] dx = new Vector3[maxDots];
			nd.CopyTo(dx, 0);
			if (crossProjection)
			{
				//project all vertices for crosseyed view:
				for (int i = 0; i < maxDots; i++)
				{
					dx[i].X = nd[i].X + (nd[i].Z * 0.1f) + xOffset;
				}
			}
			else
			{
				for (int i = 0; i < maxDots; i++)
				{
					dx[i].X = nd[i].X + xOffset;
				}
			}

			if (findFaces==1)
			{
				triListA = new int[maxDots * 4];
				triListB = new int[maxDots * 4];
				triListC = new int[maxDots * 4];
				triCount = 0;
				for (int va = 0; va < maxDots; va++)
				{
					for (int vb = va + 1; vb < maxDots; vb++)
					{
						float dist = (nd[vb] - nd[va]).Length;
						if (dist < minDist * 1.25f)
						{
							for (int vc = vb + 1; vc < maxDots; vc++)
							{
								dist = (nd[vb] - nd[vc]).Length;
								if (dist < minDist * 1.25f)
								{
									dist = (nd[va] - nd[vc]).Length;
									if (dist < minDist * 1.25f)
									{
										if (triCount < maxDots * 4)
										{
											//found a triangle
											triListA[triCount] = va;
											triListB[triCount] = vb;
											triListC[triCount] = vc;
											triCount++;
										}
									}
								}
							}
						}

					}
				}

				for (int i = 0; i < triCount; i++)
				{

					float gColor = (((p[triListA[i]].X + p[triListB[i]].X + p[triListC[i]].X) / (sphereRadius * 3f)) * 0.375f) + 0.25f;
					float bColor = (((p[triListA[i]].Y + p[triListB[i]].Y + p[triListC[i]].Y) / (sphereRadius * 3f)) * 0.375f) + 0.25f;
					float fColor = (gColor * gColor) + (bColor * bColor);
					GL.Color3(0, fColor, 1f - fColor);
					GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.Polygon);
					GL.Vertex3(dx[triListA[i]]);
					GL.Vertex3(dx[triListB[i]]);
					GL.Vertex3(dx[triListC[i]]);
					GL.End();
				}


			}

			if (findFaces==2)
			{
				GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.Polygon);
				GL.Color3(0f, 1f, 1f);
				for (var i = 0; i < maxDots; i++)
				{
					for (var j = i + 1; j < maxDots; j++)
					{
						//get distance from i to j
						float dist = (p[j] - p[i]).Length;
						if (dist < minDist * 1.01f)
						{
							GL.Color3(0f, 0f, 0f);
							GL.Vertex3(xOffset, 0f, 0f);
							GL.Color3(0f, 1f, 1f);
							GL.Vertex3(dx[i]);
							GL.Vertex3(dx[j]);
						}
						else if (lineLevel >= LineTolerance.Secondary && dist < minDist * 1.1f)
						{
							GL.Color3(0f, 0f, 0f);
							GL.Vertex3(xOffset, 0f, 0f);
							GL.Color3(0.75f, 0.75f, 0.5f);
							GL.Vertex3(dx[i]);
							GL.Vertex3(dx[j]);
						}
						else if (lineLevel == LineTolerance.Tertiary && dist < minDist * 1.25f)
						{
							GL.Color3(0f, 0f, 0f);
							GL.Vertex3(xOffset, 0f, 0f);
							GL.Color3(0.75f, 0f, 0f);
							GL.Vertex3(dx[i]);
							GL.Vertex3(dx[j]);
						}
					}
				}
				GL.End();
			}

			if (wireFrame)
			{
				GL.LineWidth(lineThickness);
				GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.Lines);
				GL.Color3(0f, 1f, 1f);
				numEdges = 0;
				//pEdges = new int[maxDots * 3];
				for (var i = 0; i < maxDots; i++)
				{
					for (var j = i + 1; j < maxDots; j++)
					{
						//get distance from i to j
						float dist = (p[j] - p[i]).Length;
						if (dist < minDist * 1.01f)
						{
							numEdges++;
							//pEdges[i]++;
							//pEdges[j]++;
							GL.Color3(0f, 1f, 1f);
							GL.Vertex3(dx[i]);
							GL.Vertex3(dx[j]);
						}
						else if (lineLevel >= LineTolerance.Secondary && dist < minDist * 1.1f)
						{
							numEdges++;
							GL.Color3(0.75f, 0.75f, 0.5f);
							GL.Vertex3(dx[i]);
							GL.Vertex3(dx[j]);
						}
						else if (lineLevel == LineTolerance.Tertiary && dist < minDist * 1.25f)
						{
							numEdges++;
							GL.Color3(0.75f, 0f, 0f);
							GL.Vertex3(dx[i]);
							GL.Vertex3(dx[j]);
						}
					}
				}
				GL.End();
			}

			if (showVerts)
			{
				//draw vertices as big points:
				GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.Points);
				GL.Color3(1f, 1f, 1f);
				GL.LineWidth(lineThickness);
				for (var i = 0; i < Math.Min(lockedVerts, maxDots); i++) GL.Vertex3(dx[i]);
				GL.Color3(1f, 1f, 1f);
				for (var i = lockedVerts; i < maxDots; i++) GL.Vertex3(dx[i]);
				GL.End();

				GL.Color3(1f, 1f, 1f); //draw circles around the lecked vertices for better visibility
				for (var i = 0; i < Math.Min(lockedVerts, maxDots); i++)
				{
					GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.LineLoop);
					foreach (Vector3 c in circle) GL.Vertex3(dx[i] + c);
					GL.End();
				}

			}
		}

		void drawFrontVisualization(float xOffset, Vector3[] nd, bool crossProjection)
		{
			bool[] showVert = new bool[maxDots];
			float zHide = sphereRadius * 0.15f;
			for (int i = 0; i < maxDots; i++)
			{
				if (nd[i].Z < zHide) showVert[i] = true;
			}

			Vector3[] dx = new Vector3[maxDots];
			nd.CopyTo(dx, 0);
			if (crossProjection)
			{
				//project all vertices for crosseyed view:
				for (int i = 0; i < maxDots; i++)
				{
					dx[i].X = nd[i].X + (nd[i].Z * 0.1f) + xOffset;
				}
			}
			else
			{
				for (int i = 0; i < maxDots; i++)
				{
					dx[i].X = nd[i].X + xOffset;
				}
			}

			if (findFaces==1)
			{
				triListA = new int[maxDots * 3];
				triListB = new int[maxDots * 3];
				triListC = new int[maxDots * 3];
				triCount = 0;
				for (int va = 0; va < maxDots; va++)
				{
					for (int vb = va + 1; vb < maxDots; vb++)
					{
						float dist = (nd[vb] - nd[va]).Length;
						if (dist < minDist * 1.25f)
						{
							for (int vc = vb + 1; vc < maxDots; vc++)
							{
								dist = (nd[vb] - nd[vc]).Length;
								if (dist < minDist * 1.25f)
								{
									dist = (nd[va] - nd[vc]).Length;
									if (dist < minDist * 1.25f)
									{
										if (showVert[va] && showVert[vb] && showVert[vc])
										{

										
										//found a triangle
										triListA[triCount] = va;
										triListB[triCount] = vb;
										triListC[triCount] = vc;
										triCount++;
										}
									}
								}
							}
						}

					}
				}

				for (int i = 0; i < triCount; i++)
				{
					float gColor = (((p[triListA[i]].X + p[triListB[i]].X + p[triListC[i]].X) / (sphereRadius * 3f)) * 0.375f) + 0.25f;
					float bColor = (((p[triListA[i]].Y + p[triListB[i]].Y + p[triListC[i]].Y) / (sphereRadius * 3f)) * 0.375f) + 0.25f;
					float fColor = (gColor * gColor) + (bColor * bColor);
					GL.Color3(0, fColor, 1f - fColor);
					GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.Polygon);
					GL.Vertex3(dx[triListA[i]]);
					GL.Vertex3(dx[triListB[i]]);
					GL.Vertex3(dx[triListC[i]]);
					GL.End();
				}


			}

			if (findFaces==2)
			{
				GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.Polygon);
				GL.Color3(0f, 1f, 1f);
				for (var i = 0; i < maxDots; i++)
				{
					if (showVert[i])
					{
						for (var j = i + 1; j < maxDots; j++)
						{
							if (showVert[j])
							{
								//get distance from i to j
								float dist = (p[j] - p[i]).Length;
								if (dist < minDist * 1.01f)
								{
									GL.Color3(0f, 0f, 0f);
									GL.Vertex3(xOffset, 0f, 0f);
									GL.Color3(0f, 1f, 1f);
									GL.Vertex3(dx[i]);
									GL.Vertex3(dx[j]);
								}
								else if (lineLevel >= LineTolerance.Secondary && dist < minDist * 1.1f)
								{
									GL.Color3(0f, 0f, 0f);
									GL.Vertex3(xOffset, 0f, 0f);
									GL.Color3(0.75f, 0.75f, 0.5f);
									GL.Vertex3(dx[i]);
									GL.Vertex3(dx[j]);
								}
								else if (lineLevel == LineTolerance.Tertiary && dist < minDist * 1.25f)
								{
									GL.Color3(0f, 0f, 0f);
									GL.Vertex3(xOffset, 0f, 0f);
									GL.Color3(0.75f, 0f, 0f);
									GL.Vertex3(dx[i]);
									GL.Vertex3(dx[j]);
								}
							}
						}
					}
				}
				GL.End();
			}

			if (wireFrame)
			{
				GL.LineWidth(lineThickness);
				GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.Lines);
				GL.Color3(0f, 1f, 1f);
				numEdges = 0;
				//pEdges = new int[maxDots * 3];

				for (var i = 0; i < maxDots; i++)
				{
					if (showVert[i])
					{
						for (var j = i + 1; j < maxDots; j++)
						{
							if (showVert[j])
							{
								//get distance from i to j
								float dist = (p[j] - p[i]).Length;
								if (dist < minDist * 1.01f)
								{
									numEdges++;
									//pEdges[i]++;
									//pEdges[j]++;
									GL.Color3(0f, 1f, 1f);
									GL.Vertex3(dx[i]);
									GL.Vertex3(dx[j]);
								}
								else if (lineLevel >= LineTolerance.Secondary && dist < minDist * 1.1f)
								{
									GL.Color3(0.75f, 0.75f, 0.5f);
									GL.Vertex3(dx[i]);
									GL.Vertex3(dx[j]);
								}
								else if (lineLevel == LineTolerance.Tertiary && dist < minDist * 1.25f)
								{
									GL.Color3(0.75f, 0f, 0f);
									GL.Vertex3(dx[i]);
									GL.Vertex3(dx[j]);
								}
							}
						}
					}
					
					
				}
				GL.End();
			}

			if (showVerts)
			{
				//draw vertices as big points:
				GL.LineWidth(lineThickness);
				GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.Points);
				GL.Color3(1f, 1f, 1f);
					for (var i = 0; i < maxDots; i++)
					{
						if (showVert[i])
						{
							GL.Vertex3(dx[i]);
						}
					}
					GL.End();
			}
		}

		void drawFrontVisualizationCentered(Vector3[] nd)
		{
			if (findFaces==1)
			{
				triListA = new int[maxDots * 3];
				triListB = new int[maxDots * 3];
				triListC = new int[maxDots * 3];
				triCount = 0;
				for (int va = 0; va < maxDots; va++)
				{
					for (int vb = va + 1; vb < maxDots; vb++)
					{
						float dist = (nd[vb] - nd[va]).Length;
						if (dist < minDist * 1.25f)
						{
							for (int vc = vb + 1; vc < maxDots; vc++)
							{
								dist = (nd[vb] - nd[vc]).Length;
								if (dist < minDist * 1.25f)
								{
									dist = (nd[va] - nd[vc]).Length;
									if (dist < minDist * 1.25f)
									{
										//found a triangle
										triListA[triCount] = va;
										triListB[triCount] = vb;
										triListC[triCount] = vc;
										triCount++;
									}
								}
							}
						}

					}
				}

				for (int i = 0; i < triCount; i++)
				{

					float gColor = (((p[triListA[i]].X + p[triListB[i]].X + p[triListC[i]].X) / (sphereRadius * 3f)) * 0.375f) + 0.25f;
					float bColor = (((p[triListA[i]].Y + p[triListB[i]].Y + p[triListC[i]].Y) / (sphereRadius * 3f)) * 0.375f) + 0.25f;
					float fColor = (gColor * gColor) + (bColor * bColor);
					GL.Color3(0, fColor, 1f - fColor);
					GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.Polygon);
					GL.Vertex3(nd[triListA[i]]);
					GL.Vertex3(nd[triListB[i]]);
					GL.Vertex3(nd[triListC[i]]);
					GL.End();
				}


			}

			if (findFaces==2)
			{
				GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.Polygon);
				GL.Color3(0f, 1f, 1f);
				for (var i = 0; i < maxDots; i++)
				{
					if (nd[i].Z < 0f)
					{
						for (var j = i + 1; j < maxDots; j++)
						{
							if (nd[j].Z < 0f)
							{
								//get distance from i to j
								float dist = (p[j] - p[i]).Length;
								if (dist < minDist * 1.01f)
								{
									GL.Color3(0f, 0f, 0f);
									GL.Vertex3(0f, 0f, 0f);
									GL.Color3(0f, 1f, 1f);
									GL.Vertex3(nd[i]);
									GL.Vertex3(nd[j]);
								}
								else if (lineLevel >= LineTolerance.Secondary && dist < minDist * 1.1f)
								{
									GL.Color3(0f, 0f, 0f);
									GL.Vertex3(0f, 0f, 0f);
									GL.Color3(0.75f, 0.75f, 0.5f);
									GL.Vertex3(nd[i]);
									GL.Vertex3(nd[j]);
								}
								else if (lineLevel == LineTolerance.Tertiary && dist < minDist * 1.25f)
								{
									GL.Color3(0f, 0f, 0f);
									GL.Vertex3(0f, 0f, 0f);
									GL.Color3(0.75f, 0f, 0f);
									GL.Vertex3(nd[i]);
									GL.Vertex3(nd[j]);
								}
							}
						}
					}
				}
				GL.End();
			}

			if (wireFrame)
			{
				GL.LineWidth(lineThickness);
				GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.Lines);
				GL.Color3(0f, 1f, 1f);
				numEdges = 0;
				//pEdges = new int[maxDots * 3];
				for (var i = 0; i < maxDots; i++)
				{
					if (nd[i].Z < 0)
					{
						for (var j = i + 1; j < maxDots; j++)
						{
							if (nd[j].Z < 0)
							{
								//get distance from i to j
								float dist = (p[j] - p[i]).Length;
								if (dist < minDist * 1.01f)
								{
									numEdges++;
									//pEdges[i]++;
									//pEdges[j]++;
									GL.Color3(0f, 1f, 1f);
									GL.Vertex3(nd[i]);
									GL.Vertex3(nd[j]);
								}
								else if (lineLevel >= LineTolerance.Secondary && dist < minDist * 1.1f)
								{
									GL.Color3(0.75f, 0.75f, 0.5f);
									GL.Vertex3(nd[i]);
									GL.Vertex3(nd[j]);
								}
								else if (lineLevel == LineTolerance.Tertiary && dist < minDist * 1.25f)
								{
									GL.Color3(0.75f, 0f, 0f);
									GL.Vertex3(nd[i]);
									GL.Vertex3(nd[j]);
								}

							}
						}
					}

				}
				GL.End();
			}

			if (showVerts)
			{
				//draw vertices as big points:
				GL.LineWidth(lineThickness);
				GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.Points);
				GL.Color3(1f, 1f, 1f);
				for (var i = 0; i < maxDots; i++)
				{
					if (nd[i].Z < 0f) GL.Vertex3(nd[i]);
				}
				GL.End();
			}
		}

		void drawVisualizationCentered(Vector3[] nd)
		{
			if (findFaces==1)
			{
				triListA = new int[maxDots * 3];
				triListB = new int[maxDots * 3];
				triListC = new int[maxDots * 3];
				triCount = 0;
				for (int va = 0; va < maxDots; va++)
				{
					for (int vb = va + 1; vb < maxDots; vb++)
					{
						float dist = (nd[vb] - nd[va]).Length;
						if (dist < minDist * 1.25f)
						{
							for (int vc = vb + 1; vc < maxDots; vc++)
							{
								dist = (nd[vb] - nd[vc]).Length;
								if (dist < minDist * 1.25f)
								{
									dist = (nd[va] - nd[vc]).Length;
									if (dist < minDist * 1.25f)
									{
										//found a triangle
										triListA[triCount] = va;
										triListB[triCount] = vb;
										triListC[triCount] = vc;
										triCount++;
									}
								}
							}
						}

					}
				}

				for (int i = 0; i < triCount; i++)
				{

					float gColor = (((p[triListA[i]].X + p[triListB[i]].X + p[triListC[i]].X) / (sphereRadius * 3f)) * 0.375f) + 0.25f;
					float bColor = (((p[triListA[i]].Y + p[triListB[i]].Y + p[triListC[i]].Y) / (sphereRadius * 3f)) * 0.375f) + 0.25f;
					float fColor = (gColor * gColor) + (bColor * bColor);
					GL.Color3(0, fColor, 1f - fColor);
					GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.Polygon);
					GL.Vertex3(nd[triListA[i]]);
					GL.Vertex3(nd[triListB[i]]);
					GL.Vertex3(nd[triListC[i]]);
					GL.End();
				}


			}

			if (findFaces==2)
			{
				GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.Polygon);
				GL.Color3(0f, 1f, 1f);
				for (var i = 0; i < maxDots; i++)
				{
					for (var j = i + 1; j < maxDots; j++)
					{
						//get distance from i to j
						float dist = (p[j] - p[i]).Length;
						if (dist < minDist * 1.01f)
						{
							GL.Color3(0f, 0f, 0f);
							GL.Vertex3(0f, 0f, 0f);
							GL.Color3(0f, 1f, 1f);
							GL.Vertex3(nd[i]);
							GL.Vertex3(nd[j]);
						}
						else if (lineLevel >= LineTolerance.Secondary && dist < minDist * 1.1f)
						{
							GL.Color3(0f, 0f, 0f);
							GL.Vertex3(0f, 0f, 0f);
							GL.Color3(0.75f, 0.75f, 0.5f);
							GL.Vertex3(nd[i]);
							GL.Vertex3(nd[j]);
						}
						else if (lineLevel == LineTolerance.Tertiary && dist < minDist * 1.25f)
						{
							GL.Color3(0f, 0f, 0f);
							GL.Vertex3(0f, 0f, 0f);
							GL.Color3(0.75f, 0f, 0f);
							GL.Vertex3(nd[i]);
							GL.Vertex3(nd[j]);
						}
					}
				}
				GL.End();
			}

			if (wireFrame)
			{
				GL.LineWidth(lineThickness);
				GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.Lines);
				GL.Color3(0f, 1f, 1f);
				numEdges = 0;
				//pEdges = new int[maxDots * 3];
				for (var i = 0; i < maxDots; i++)
				{
					for (var j = i + 1; j < maxDots; j++)
					{
						//get distance from i to j
						float dist = (p[j] - p[i]).Length;
						if (dist < minDist * 1.01f)
						{
							numEdges++;
							//pEdges[i]++;
							//pEdges[j]++;
							GL.Color3(0f, 1f, 1f);
							GL.Vertex3(nd[i]);
							GL.Vertex3(nd[j]);
						}
						else if (lineLevel >= LineTolerance.Secondary && dist < minDist * 1.1f)
						{
							GL.Color3(0.75f, 0.75f, 0.5f);
							GL.Vertex3(nd[i]);
							GL.Vertex3(nd[j]);
						}
						else if (lineLevel == LineTolerance.Tertiary && dist < minDist * 1.25f)
						{
							GL.Color3(0.75f, 0f, 0f);
							GL.Vertex3(nd[i]);
							GL.Vertex3(nd[j]);
						}
					}
				}
				GL.End();
			}

			if (showVerts)
			{
				//draw vertices as big points:
				GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.Points);
				GL.Color3(1f, 1f, 1f);
				GL.LineWidth(lineThickness);
				for (var i = 0; i < Math.Min(lockedVerts, maxDots); i++) GL.Vertex3(nd[i]);
				GL.Color3(1f, 1f, 1f);
				for (var i = lockedVerts; i < maxDots; i++) GL.Vertex3(nd[i]);
				GL.End();
				
				GL.Color3(1f, 1f, 1f); //draw circles around the lecked vertices for better visibility
				for (var i = 0; i < Math.Min(lockedVerts, maxDots); i++)
				{
					GL.Begin(OpenTK.Graphics.OpenGL.PrimitiveType.LineLoop);
					foreach (Vector3 c in circle) GL.Vertex3(nd[i] + c);
					GL.End();
				}
			}
		}


		void stopSounds()
		{
			foreach (SourceVoice s in sourceVoice)
			{
				s.Stop();
			}
		}

		void playSounds()
		{
			voiceLoop++;
			if (voiceLoop > 2)
			{
				int numPitches = 0;
				float[] pitch = new float[maxDots * 3]; //in rare cases this might be exceeded so we need to do some bounds checking on the array

				if (soundOn == 1)
				{
					for (var i = 0; i < maxDots; i++)
					{
						for (var j = i + 1; j < maxDots; j++)
						{
							//get distance from i to j
							float dist = (p[j] - p[i]).Length;
							if (dist < minDist * 1.25f)
							{
								pitch[numPitches] = dist / minDist;
								numPitches++;
								if (numPitches >= pitch.Length) break;
							}
						}
						if (numPitches >= pitch.Length) break;
					}
				}
				else
				{
					//do face-area based sounds.
					// This could be optimized for certain setting combinations by using the face-checking built into each "draw" function
					// but I put it here out of laziness. It should only affect situations with high number of faces when face-sound is on
					// and will also avoid extra overhead of face-finding when face-sound is off.
					triListA = new int[maxDots * 4];
					triListB = new int[maxDots * 4];
					triListC = new int[maxDots * 4];
					triArea = new float[maxDots * 4];
					triCount = 0;
					for (int va = 0; va < maxDots; va++)
					{
						for (int vb = va + 1; vb < maxDots; vb++)
						{
							float dist1 = (p[vb] - p[va]).Length;
							if (dist1 < minDist * 1.25f)
							{
								for (int vc = vb + 1; vc < maxDots; vc++)
								{
									float dist2 = (p[vb] - p[vc]).Length;
									if (dist2 < minDist * 1.25f)
									{
										float dist3 = (p[va] - p[vc]).Length;
										if (dist3 < minDist * 1.25f)
										{
											if (triCount < maxDots * 4)
											{
												//found a triangle
												triListA[triCount] = va;
												triListB[triCount] = vb;
												triListC[triCount] = vc;
												//get the area
												float s = (dist1 + dist2 + dist3) / 2f;
												triArea[triCount] = (float)Math.Sqrt(s * (s - dist1) * (s - dist2) * (s - dist3));
												triCount++;
											}
										}
									}
								}
							}

						}
					}
					
					//play the sounds based on area of each face compared to min:
					float maxArea = 0f;
					for(int i = 0; i < triArea.Length; i++)
					{
						if (triArea[i] > maxArea) maxArea = triArea[i];
					}
					//we have the largest, now populate the list of pitches using this info
					for (int i = 0; i < triArea.Length; i++)
					{

						if (triArea[i] > 0)
						{
							pitch[numPitches] = maxArea / triArea[i];// / maxArea;
							numPitches++;
						}
					}
				}

				voiceLoop = 0;
				currentVoice++;
				if (currentVoice >= sourceVoice.Length) currentVoice = 0;
				sourceVoice[currentVoice].Stop();

				int r = random.Next(0, numPitches);
				float newpitch = ((pitch[r] -1f) * 4f)+0.5f; //pitch[r];
														   //Console.WriteLine(pitch[r].ToString());
				sourceVoice[currentVoice].SetVolume(0.1f);
				sourceVoice[currentVoice].SetFrequencyRatio(newpitch);

				sourceVoice[currentVoice].SubmitSourceBuffer(buffer, soundstream.DecodedPacketsInfo);
				sourceVoice[currentVoice].Start();
			}
		}

		protected override void OnUpdateFrame(FrameEventArgs e)
		{
			base.OnUpdateFrame(e);

			if (autoSearch)
			{
				findFaces = 0;
				//for each number, do 20 resets
				// for each reset, 
				// let it run until it has stabilized
				// take a screenshot titled maxdots _ iteration

				if (toleranceReached)
				{
					System.Drawing.Bitmap bmp = takeScreenshot();
					var encoderParameters = new System.Drawing.Imaging.EncoderParameters(1);
					encoderParameters.Param[0] = new System.Drawing.Imaging.EncoderParameter(System.Drawing.Imaging.Encoder.Quality, 1L);
					System.IO.Directory.CreateDirectory("autosearch");

					//set up filename
					string outName = maxDots.ToString() + "_" + autoSearchIteration.ToString().PadLeft(2) + ".png";
					string fName = System.IO.Directory.GetCurrentDirectory() + @"\autosearch\" + outName;
					bmp.Save(fName, GetEncoder(System.Drawing.Imaging.ImageFormat.Png), encoderParameters);

					autoSearchIteration++;
					if (autoSearchIteration > 20)
					{
						autoSearchIteration = 0;
						maxDots++;
					}
					initSphere();
				}
			}

			processInput(e);
			if (!haltGrav && !toleranceReached) divideSphere();
		}

		bool wasPressed(Key key)
		{
			return (keyboard[key] && !lastkeyboard[key]);
		}

		//if a key is being held down, after 700 ms, we need to start repeating the keystroke
		void setKeyRepeat(int k, Key key, int t)
		{
			if (keyboard[key] )
			{
				if (lastkeyboard[key])
				{
					//a key needs to be repeated when:
					// it is down now, it was down last time, timer is less than 0
					keyTimers[k] -= t;
					if (keyTimers[k] <= 0)
					{
						keysHeld[k] = true;
						keyTimers[k] = 50;
					}

				}
				else 
				{
					//first time through here since pressing this key, set the timer for longer
					keyTimers[k] = 350;
				}
					
			}

		}

		void processInput(FrameEventArgs e)
		{
			keyboard = OpenTK.Input.Keyboard.GetState();
			int dT = (int)(e.Time * 1000);
			setKeyRepeat((int)keysUsed.Left, Key.Left, dT);
			setKeyRepeat((int)keysUsed.Right, Key.Right, dT);
			setKeyRepeat((int)keysUsed.PageUp, Key.PageUp, dT);
			setKeyRepeat((int)keysUsed.PageDown, Key.PageDown, dT);
			setKeyRepeat((int)keysUsed.Enter, Key.Enter, dT);

			if (!Focused) return; //only process if window has focus!

			if (keyboard.IsKeyDown(Key.Escape) && !lastkeyboard.IsKeyDown(Key.Escape))
			{
				if (inputMode)
				{
					inputMode = false;
				}
				else
				{
					if (showHelp)
					{
						showHelp = false;
					}
					else
					{
						exitQuestion = !exitQuestion;
					}
				}
			}
			if (wasPressed(Key.Y) && exitQuestion) Exit();



			// Stellate or tesselate
			if (wasPressed(Key.S))
			{
				if (keyboard.IsKeyDown(Key.ShiftLeft) || keyboard.IsKeyDown(Key.ShiftRight))
				{
					tesselateNow();
				}
				else
				{
					stellateNow();
				}
			}
			if (wasPressed(Key.BackSpace))
			{
				if (inputMode)
				{
					if (inputVal.Length > 0) inputVal = inputVal.Remove(inputVal.Length - 1, 1);
				}
				else
				{
					initSphere();
				}
			}


			if (wasPressed(Key.F12)) writeTxtFile(keyboard.IsKeyDown(Key.LShift) || keyboard.IsKeyDown(Key.RShift));

			if (wasPressed(Key.F1)) showHelp = !showHelp;

			if (wasPressed(Key.L))
			{
				if (lockedVerts > 0 && (keyboard.IsKeyDown(Key.LShift) || keyboard.IsKeyDown(Key.RShift)))
				{
					lockedVerts = 0;
					createMessage("Vertices unlocked", -1000, 800, 3, 3000);
				}
				else
				{
					lockedVerts = maxDots;
					p.CopyTo(pLocked, 0); //just copy the whole thing, too lay to write a for loop to only copy the needed elements
											// plus it's not in a loop so nobody will notice, shhhhhh!
					createMessage(lockedVerts + " Vertices Locked", -1000, 800, 3, 3000);
				}
			}

			if (wasPressed(Key.Period)) lineThickness *= 1.5f;
			if (wasPressed(Key.Comma)) { lineThickness /= 1.5f; if (lineThickness < 1f) lineThickness = 1f; }
			if (wasPressed(Key.Insert)) binocSplit *= 1.025f;
			if (wasPressed(Key.Delete)) binocSplit /= 1.025f;
			if (wasPressed(Key.Home)) { gravConst = 25000f; createMessage("High Repulsion ", -1000, 800, 3, 3000); toleranceReached = false; }
			if (wasPressed(Key.End)){ gravConst = 250f; createMessage("Low Repulsion ", -1000, 800, 3, 3000); toleranceReached = false; }

			if (wasPressed(Key.R))
			{
				if (keyboard.IsKeyDown(Key.ShiftLeft) || keyboard.IsKeyDown(Key.ShiftRight))
				{
					rotateNow = false;
					spinAngle = 0f;
					spinAngleY = 0f;
					createMessage("Rotation Reset", -1000, 800, 3, 3000);
				}
				else
				{ 
					rotateNow = !rotateNow;
				}
			}

			if (wasPressed(Key.P)) soundOn++; if (soundOn > 2) soundOn = 0;
			if (wasPressed(Key.M)) hideMessage = !hideMessage;
			if (wasPressed(Key.K)) showBacks = !showBacks;
			if (wasPressed(Key.B)) binocular = !binocular;
			if (wasPressed(Key.H)) {haltGrav = !haltGrav; createMessage("Repulsion " + (haltGrav ? "OFF" : "ON"), -1000, 800, 3, 3000); }
			if (wasPressed(Key.T)) {fixedTop = !fixedTop; createMessage("Fixed Top " + (fixedTop ? "ON" : "OFF"), -1000, 800, 3, 3000); }
			if (wasPressed(Key.F)) findFaces++; if (findFaces > 2) findFaces = 0;
			if (wasPressed(Key.W)) wireFrame = !wireFrame;
			if (wasPressed(Key.V)) showVerts = !showVerts;
			if (wasPressed(Key.D))
			{
				lineLevel++;
				if (lineLevel > LineTolerance.Tertiary) lineLevel = LineTolerance.primaryOnly;
				string[] lMess = new string[] { "Primary", "Secondary", "Tertiary" };
				createMessage("Lines: " + lMess[(int)lineLevel], -1000f, 800f, 3, 3000);
			}
			if (wasPressed(Key.Right) || keysHeld[(int)keysUsed.Right])
			{
				keysHeld[(int)keysUsed.Right] = false;
				maxDots++;
				createMessage(maxDots.ToString() + " Vertices", -1000f, 800f, 3, 5000);
				initSphere();
			}
			if (wasPressed(Key.Left) || keysHeld[(int)keysUsed.Left])
			{
				keysHeld[(int)keysUsed.Left] = false;
				maxDots--;
				if (maxDots < 4) maxDots = 4;
				createMessage(maxDots.ToString() + " Vertices", -1000f, 800f, 3, 5000);
				initSphere();
			}

			if (wasPressed(Key.PageUp) || keysHeld[(int)keysUsed.PageUp])
			{
				keysHeld[(int)keysUsed.PageUp] = false;
				zWall += 10f;
				if (zWall > sphereRadius + 10f) zWall = sphereRadius + 10f;
				createMessage("z Wall " + zWall.ToString(), -1000f, 800f, 3, 3000);
			}
			if (wasPressed(Key.PageDown) || keysHeld[(int)keysUsed.PageDown])
			{
				keysHeld[(int)keysUsed.PageDown] = false;
				zWall -= 10f;
				if (zWall < -sphereRadius - 10f) zWall = -sphereRadius - 10f;
				createMessage("z Wall " + zWall.ToString(), -1000f, 800f, 3, 3000);
			}

			if (wasPressed(Key.N))
			{
				if (exitQuestion)
				{
					exitQuestion = false;
				}
				else
				{
					inputMode = true;
					inputVal = "";
				}
			}

			if (inputMode) //check for numeric characters being entered
			{
				if (keyboard.IsAnyKeyDown)
				{
					for (int offset = 0; offset < 10; offset++)
					{
						if ((keyboard.IsKeyDown((Key)offset + 67) && !lastkeyboard.IsKeyDown((Key)offset + 67)) || (keyboard.IsKeyDown((Key)offset + 109) && !lastkeyboard.IsKeyDown((Key)offset + 109))) inputVal += offset.ToString();
					}
					createMessage("VERTICES: " + inputVal, -1000, 900, 3, -100000);
				}
			}

			if (wasPressed(Key.Enter) || keysHeld[(int)keysUsed.Enter])
			{
				if (inputMode)
				{ //user just finished entering a number
					if (inputVal.Length > 0)
					{
						int tNum = Convert.ToInt32(inputVal);
						if (tNum != maxDots)
						{
							inputMode = false;
							maxDots = tNum;
							initSphere();
						}
					}
				}
				else
				{
					keysHeld[(int)keysUsed.Enter] = false;
					Random r = new Random();
					for (int i = lockedVerts; i < maxDots; i++)
					{
						p[i].X += (sphereRadius * 0.1f) - ((float)r.NextDouble() * sphereRadius * 0.5f);
						p[i].Y += (sphereRadius * 0.1f) - ((float)r.NextDouble() * sphereRadius * 0.5f);
						p[i].Z += (sphereRadius * 0.1f) - ((float)r.NextDouble() * sphereRadius * 0.5f);
					}
					createMessage("Vertices bumped", -1000f, 800f, 2, 1000);
					toleranceReached = false;
				}
			}

			if (wasPressed(Key.PrintScreen))
			{
				createMessage("WARNING: SCREENSHOT NOT SAVED! UNKNOWN REASON", -1000, 900, 3, 10000);

				System.Drawing.Bitmap bmp = takeScreenshot();
				var encoderParameters = new System.Drawing.Imaging.EncoderParameters(1);
				encoderParameters.Param[0] = new System.Drawing.Imaging.EncoderParameter(System.Drawing.Imaging.Encoder.Quality, 1L);
				System.IO.Directory.CreateDirectory("screenshots");

				//find a filename that isn't taken
				string currentDirName = System.IO.Directory.GetCurrentDirectory();
				string[] files = System.IO.Directory.GetFiles(currentDirName + @"\screenshots", "*.png");
				string outName="";
				for (int i = 0; i < 10000; i++)
				{
					bool success = true;
					outName = "Sphere_" + i.ToString().PadLeft(4, '0') + ".png";
					foreach (string s in files)
					{
						if (Path.GetFileName(s)  == outName)
						{
							success = false;
							break;
						}
					}
					if (success) break;
				}
					if (outName != "Sphere_9999.png") 
				{
					string fName = currentDirName + @"\screenshots\" + outName;
					bmp.Save(fName, GetEncoder(System.Drawing.Imaging.ImageFormat.Png), encoderParameters);
					createMessage("SCREENSHOT \'" + outName + "\' SAVED!", -1000, 900, 3, 10000);
				}
				else
				{
					createMessage("WARNING: SCREENSHOT DIR IS FULL! FILE NOT SAVED!",-1000,900,3,10000);
				}

			}

			lastkeyboard = keyboard;
			
			if (Mouse.GetState().LeftButton == OpenTK.Input.ButtonState.Pressed)
			{
				// on the first tick of mouse being pressed, do not calculate the delta from the last time mousepos was stored
				// otherwise it jumps way too far and unpredictably for the user
				if (lastButtonState)
				{
					Vector2 delta = lastMousePos - new Vector2(Mouse.GetState().X, Mouse.GetState().Y);
					//lock to either X or Y axis to make rotating less difficult:
					if (Math.Abs(delta.X) > Math.Abs(delta.Y)) 	spinAngle -= delta.X / 100;
					else                    spinAngleY -= delta.Y / 100;
				}
				
				lastMousePos = new Vector2(Mouse.GetState().X, Mouse.GetState().Y);
				//createMessage("Spin " + ((int)(spinAngle*180/Math.PI)).ToString() + "," + ((int)(spinAngleY*180/Math.PI)).ToString(), -1000f, 800f, 2, 1000);
			}

			int deltaWheel = lastWheel - Mouse.GetState().Wheel;
			if (deltaWheel > 0)
			{
				viewScale *= 1.05f;
				createMessage("Zoom " + (1/viewScale).ToString(), -1000, 800, 3, 3000);
			}
			if (deltaWheel < 0)
			{
				viewScale /= 1.05f;
				createMessage("Zoom " + (1/viewScale).ToString(), -1000, 800, 3, 3000);
			}
			lastWheel = Mouse.GetState().Wheel;
			lastButtonState = Mouse.GetState().LeftButton == OpenTK.Input.ButtonState.Pressed;
		}

		public System.Drawing.Bitmap takeScreenshot()
		{
			if (OpenTK.Graphics.GraphicsContext.CurrentContext == null)
				throw new OpenTK.Graphics.GraphicsContextMissingException();
			System.Drawing.Bitmap bmp = new System.Drawing.Bitmap(Width,Height);
			System.Drawing.Imaging.BitmapData data =
				bmp.LockBits(ClientRectangle, System.Drawing.Imaging.ImageLockMode.WriteOnly, System.Drawing.Imaging.PixelFormat.Format24bppRgb);
			GL.ReadPixels(0, 0, Width, Height, PixelFormat.Bgr, PixelType.UnsignedByte, data.Scan0);
			bmp.UnlockBits(data);

			bmp.RotateFlip(System.Drawing.RotateFlipType.RotateNoneFlipY);
			return bmp;
		}

		private static System.Drawing.Imaging.ImageCodecInfo GetEncoder(System.Drawing.Imaging.ImageFormat format)
		{
			var codecs = System.Drawing.Imaging.ImageCodecInfo.GetImageDecoders();
			foreach (var codec in codecs)
			{
				if (codec.FormatID == format.Guid)
				{
					return codec;
				}
			}
			return null;
		}

		void tesselateNow()
		{
			int oldMax = maxDots;
			List<Vector3> newpoints = new List<Vector3>();
			for (int i = 0; i < maxDots; i++)
			{
				for (int j = i + 1; j < maxDots; j++)
				{ // find any line segments within our acceptable length range
					float dist = (p[j] - p[i]).Length;
					if (dist < minDist * 1.25)
					{
						//put a new vertex at the center of this edge
						Vector3 n = (p[j] + p[i]) / 2;
						n.Normalize();
						n *= sphereRadius;//project vertex onto the sphere's surface
						newpoints.Add(n);
					}
				}
			}
			//we now have a list of the new points to be added, update the arrays:
			int k = maxDots;
			foreach (Vector3 t in newpoints)
			{ //copy all our new points into the end of the last one
				p[k] = t;
				k++;
			}
			maxDots += newpoints.Count; //p should now contain all the new tesselated elements

			v.Initialize();
			lastp.Initialize();
			createMessage("Tessellated " + oldMax + " to " + maxDots, -1000, 800, 3, 5000);
			divideSphere();
		}

		void stellateNow()
		{
			int oldMax = maxDots;
			List<Vector3> newpoints = new List<Vector3>();
			
			triListA = new int[maxDots * 3];
			triListB = new int[maxDots * 3];
			triListC = new int[maxDots * 3];
			triCount = 0;
			for (int va = 0; va < maxDots; va++)
			{
				for (int vb = va + 1; vb < maxDots; vb++)
				{
					float dist = (p[vb] - p[va]).Length;
					if (dist < minDist * 1.25f)
					{
						for (int vc = vb + 1; vc < maxDots; vc++)
						{
							dist = (p[vb] - p[vc]).Length;
							if (dist < minDist * 1.25f)
							{
								dist = (p[va] - p[vc]).Length;
								if (dist < minDist * 1.25f)
								{
									//found a triangle
									Vector3 n = (p[va] + p[vb] + p[vc]) / 3f;
									n.Normalize();
									n *= sphereRadius;//project vertex onto the sphere's surface
									newpoints.Add(n);
								}
							}
						}
					}

				}
			}

			//we now have a list of the new points to be added, update the arrays:
			int k = maxDots;
			foreach (Vector3 t in newpoints)
			{ //copy all our new points into the end of the last one
				p[k] = t;
				k++;
			}
			maxDots += newpoints.Count; //p should now contain all the new stellated elements

			v.Initialize();
			lastp.Initialize();

			createMessage("Stellated " + oldMax + " to " + maxDots, -1000, 800, 3, 5000);
			divideSphere();
		}

		void initHelpMessage()
		{
			int mLen = 0;
			string[] s = new string[]
			{
				"---- SPHERE DIVIDER BY LIFT PIZZAS ---- ",
				"  ",
				"F1 = THIS HELP SCREEN",
				"ESC = QUIT",
				"  ",
				"--------- SIMULATION PARAMETERS -----",
				"  ",
				"BACKSPACE = REPOSITION ALL VERTICES",
				"ENTER = BUMP VERTICES",
				"LEFT/RIGHT = ADD/REMOVE A VERTEX",
				"N = ENTER NUMBER OF VERTICES",
				"S/SHIFT+S = STELLATE/TESSELATE (SUBDIVIDE FACES/EDGES)",
				"L = LOCK CURRENT VERTICES IN POSITION",
				"SHIFT+L = LOCK CURRENT VERTICES IN POSITION",
				"T = FIX ONE VERTEX TO TOP POSITION",
				"  ",
				"--------- VISUALIZATION --------------",
				"  ",
				"MOUSE SCROLL = ZOOM IN/OUT",
				"MOUSE CLICK/DRAG = ROTATE",
				"B = TOGGLE (CROSSEYED) BINOCULAR VIEW",
				"INSERT/DELETE = ADJUST BINOCULAR POSITION",
				"R = AUTO-ROTATION",
				"SHIFT+R = RESET ROTATION",
				"K = SHOW/HIDE BACK HALF",
				"D = DISPLAY PRIMARY/SECONDARY/TERTIARY LINES",
				"< > = ADJUST LINE THICKNESS",
				"PAGEUP/DN = ADJUST Z-WALL POSITION",
				"V = SHOW/HIDE VERTICES",
				"W = SHOW/HIDE WIREFRAME",
				"F = SHOW/HIDE (TRIANGLE) FACES AND FLOWER VIEW",
				"  ",
				"---------- OTHER -------------",
				"  ",
				"HOME/END = HIGH/LOW REPULSION STRENGTH",
				"H = TURN OFF REPULSION (IMPROVES FPS)",
				"M = SHOW/HIDE STATUS MESSAGES",
				"F12 = EXPORT MESH TO TEXTFILE (SHIFT EXPORTS FLOWER MESH)",
				"PRINTSCREEN = SCREENSHOT",
				"P = PLAY SOUNDS (EXPERIMENTAL AND ANNOYING)"
			};

			float curY = -950f;
			foreach (string str in s)
			{
				float[][] nextLine = addHelpLine(str, curY);
				//find any null indices at the end, because chars might not have been added because of missing font glyphs
				int i = 0;
				while(i < nextLine.Length)
				{
					if (nextLine[i] == null || nextLine[i].Length == 0) break;
					i++;
				}// i now equals the number of chars
				helpMessage[mLen] = new float[i][]; //dim the new array so we can copy to it
				for (int j = 0; j < i; j++)
				{
					for (int k = 0; k < nextLine[j].Length; k++)
					{
						helpMessage[mLen][j] = new float[nextLine[j].Length];
							
					}
					Array.Copy(nextLine[j], helpMessage[mLen][j], helpMessage[mLen][j].Length);
				}

				curY += 48f;
				mLen++;
			}

		}

		float[][] addHelpLine(string s, float y)
		{
			float x = -500;
			float scale = 1.9f;
			byte[] ca = Encoding.ASCII.GetBytes(s.ToUpper());
			float[][] outMessage = new float[ca.Length][]; //[character][vertices]
			float totalScale = scale * viewScale;
			int mLength = 0;
			for (int i = 0; i < ca.Length; i++)
			{
				if (charVector[ca[i]] != null && charVector[ca[i]].Length != 0)
				{
					//for each character, add the list of verts
					outMessage[mLength] = new float[charVector[ca[i]].Length];

					//offset the character positions and insert them into the message
					for (int j = 0; j < charVector[ca[i]].Length; j++)
					{ //copy the vertices for this one character

						outMessage[mLength][j] = (charVector[ca[i]][j] * totalScale) + x * viewScale;
						j++;
						outMessage[mLength][j] = (charVector[ca[i]][j] * totalScale) + y * viewScale;
					}
					
					mLength++;
					x += 13 * scale;
				}
			}
			return outMessage;
		}

		//will add a character or string to the display list
		void createMessage(string s,float x, float y, float scale, int howLong)
		{
			float totalScale = scale * viewScale;
			messageLength = 0;
			byte[] ca = Encoding.ASCII.GetBytes(s.ToUpper());
			for (int i = 0; i < ca.Length; i++)
			{
				if (charVector[ca[i]]!=null && charVector[ca[i]].Length != 0)
				{
					//for each character, add the list of verts
					displayString[messageLength] = new float[charVector[ca[i]].Length];
					//offset the character positions and insert them into the message
					for (int j = 0; j < charVector[ca[i]].Length; j++)
					{ //copy the vertices for this one character
						
						displayString[messageLength][j] = (charVector[ca[i]][j] * totalScale) + x*viewScale;
						j++;
						displayString[messageLength][j] = (charVector[ca[i]][j] * totalScale) + y*viewScale;
					}
					messageLength++;
					x += 13 * scale ;
					if (x > (950f * ((float)Width / (float)Height) / viewScale))
					{
						x = -1000 / viewScale;
						y += 25 * totalScale;
					}
				}
			}
			messageTime = howLong;
		}

		protected override void OnFocusedChanged(EventArgs e)
		{
			base.OnFocusedChanged(e);
			lastMousePos = new Vector2(OpenTK.Input.Mouse.GetState().X, OpenTK.Input.Mouse.GetState().Y);
		}

		
		void initSphere()
		{
			if (maxDots > 32768) maxDots = 32768;
			empty.CopyTo(lastp, 0); 
			
			//now that maxdots points to a different ending, if there are locked verts, they need to be copied in, or do they?
			for (int i = 0; i < lockedVerts; i++)
			{
				p[i] = pLocked[i];
			}
			Random r = new Random();
			for (int i = lockedVerts; i < maxDots; i++)
			{
				p[i].X = (sphereRadius / 2) - ((float)r.NextDouble() * sphereRadius);
				p[i].Y = (sphereRadius / 2) - ((float)r.NextDouble() * sphereRadius);
				p[i].Z = (sphereRadius / 2) - ((float)r.NextDouble() * sphereRadius);
				v[i] = Vector3.Zero;
			}
			
			toleranceReached = false;
			tickCount = 0;
			curTime = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
			lastTime = curTime;
			spinAngle = 0f;
			spinAngleY = 0f;
			haltGrav = false;
			stopSounds();
		}


		
		void divideSphere()
		{
			//find the time since starting, avoid going over 30 ms
			long startTime = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
			long looptime = 0;
			//curTime = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
			//deltaTime = curTime - lastTime;
			//lastTime = curTime;

			// check to see if the points are no longer being jostled around enough to make a difference
			// this way we can stop calculating all this and get better responsiveness on the GUI with higher numbers of verts
			//check this once per long cycle (update), not every single iteration of the inner loop
			toleranceReached = true;
			float tolerance = 0.0000001f;
			for (int i = 0; i < maxDots; i++)
			{
				if ((p[i] - lastp[i]).Length > tolerance)
				{
					toleranceReached = false;
					break;
				}
			}
			p.CopyTo(lastp, 0); //store these for next comparison

			tempTicks = 0;
			bool loopInterrupt = false;

			while (!loopInterrupt)
			{
				long thisLoopTime = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
				//main loop
				tempTicks++;
				tickCount++;

				minDist = 9999999999f;
				float maxDist = 0f;

				//repulse points away from each other
				for (int i = 0; i < maxDots; i++)
				{
					for (int j = i + 1; j < maxDots; j++)
					{
						//get distance from point I to point J and scale with gravity
						Vector3 d = (p[j] - p[i]);
						float distGrav = gravConst / d.LengthSquared;
						d *= distGrav;

						if (i >= lockedVerts)
						{
							v[i] -= d;
						}
						if (j >= lockedVerts)
						{
							v[j] += d;
						}
					}
				}

				if (fixedTop)
				{ // forces point 0
					v[0].X = 0f;
					v[0].Y = -sphereRadius;
					v[0].Z = 0f;
				}

				//align to sphere surface, set distance to sphereRadius
				for (int i = 0; i < maxDots; i++)
				{
					p[i] += v[i];//apply velocity to points
					v[i] = Vector3.Zero; // erase velocity now that it's applied

					//normalize distance from center so all points lie on the radius again
					p[i] *= (sphereRadius / p[i].Length);
				}

				//collect the distances between points, see if they are similar enough
				for (int i = 0; i < maxDots; i++)
				{
					for (int j = i + 1; j < maxDots; j++)
					{
						//get distance from point I to point J and scale with gravity
						Vector3 d = (p[j] - p[i]);
						if (d.Length > maxDist) { maxDist = d.Length; }
						if (d.Length < minDist) { minDist = d.Length; }
					}
				}
				// end of main loop

				looptime = (DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond) - startTime;
				thisLoopTime = (DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond) - thisLoopTime; //how long for one iteration
				if (looptime + thisLoopTime >=32) loopInterrupt = true;
				//if (tempTicks > 1000) loopInterrupt = true;
			}
			//Console.WriteLine(tempTicks + " ticks in " + looptime + " ms");

		}


		/*
		/// <summary>
		/// Add 4-dimensional functionality, out of curiosity, for splitting a hypersphere
		/// display will still be 3-d -> 2d. The 4th dimension can be represented in color.
		/// </summary>
		Vector4[] p4;
		Vector4[] v4;
		void divideSphere4d()
		{
			//find the time since starting, avoid going over 30 ms
			long startTime = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
			long looptime = 0;
			//curTime = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
			//deltaTime = curTime - lastTime;
			//lastTime = curTime;

			// check to see if the points are no longer being jostled around enough to make a difference
			// this way we can stop calculating all this and get better responsiveness on the GUI with higher numbers of verts
			//check this once per long cycle (update), not every single iteration of the inner loop
			toleranceReached = true;
			float tolerance = 0.0000001f;
			for (int i = 0; i < maxDots; i++)
			{
				if ((p[i] - lastp[i]).Length > tolerance)
				{
					toleranceReached = false;
					break;
				}
			}
			p.CopyTo(lastp, 0); //store these for next comparison

			tempTicks = 0;
			bool loopInterrupt = false;

			while (!loopInterrupt)
			{
				long thisLoopTime = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
				//main loop
				tempTicks++;
				tickCount++;

				minDist = 9999999999f;
				float maxDist = 0f;

				//repulse points away from each other
				for (int i = 0; i < maxDots; i++)
				{
					for (int j = i + 1; j < maxDots; j++)
					{
						//get distance from point I to point J and scale with gravity
						Vector4 d = (p4[j] - p4[i]);
						float distGrav = gravConst / d.LengthSquared;
						d *= distGrav;

						if (i >= lockedVerts)
						{
							v4[i] -= d;
						}
						if (j >= lockedVerts)
						{
							v4[j] += d;
						}
					}
				}

				if (fixedTop)
				{ // forces point 0
					v4[0].X = 0f;
					v4[0].Y = -sphereRadius;
					v4[0].Z = 0f;
					v4[0].W = 0f;
				}

				//align to sphere surface, set distance to sphereRadius
				for (int i = 0; i < maxDots; i++)
				{
					p4[i] += v4[i];//apply velocity to points
					v4[i] = Vector4.Zero; // erase velocity now that it's applied

					//normalize distance from center so all points lie on the radius again
					p4[i] *= (sphereRadius / p4[i].Length);
				}

				//collect the distances between points, see if they are similar enough
				for (int i = 0; i < maxDots; i++)
				{
					for (int j = i + 1; j < maxDots; j++)
					{
						//get distance from point I to point J and scale with gravity
						Vector4 d = (p4[j] - p4[i]);
						if (d.Length > maxDist) { maxDist = d.Length; }
						if (d.Length < minDist) { minDist = d.Length; }
					}
				}
				// end of main loop


				// until 4d rendering is added, we'll just copy the results over to the regular p (3dvector) array
				for (int i = 0;i<maxDots;i++)
				{
					p[i].X = p4[i].X;
					p[i].Y = p4[i].Y;
					p[i].Z = p4[i].Z;
				}

				looptime = (DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond) - startTime;
				thisLoopTime = (DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond) - thisLoopTime; //how long for one iteration
				if (looptime + thisLoopTime >= 32) loopInterrupt = true;
				//if (tempTicks > 1000) loopInterrupt = true;
			}
			//Console.WriteLine(tempTicks + " ticks in " + looptime + " ms");

		}
		*/

		void writeTxtFile(bool flowerMode)
		{
			//get filename/path
			SaveFileDialog saveFileDialog1 = new SaveFileDialog();
			saveFileDialog1.Filter = "Object Mesh|*.obj|Plain Text|*.txt";
			saveFileDialog1.Title = "Save Mesh File";
			saveFileDialog1.FileName = maxDots + " Vertex Sphere";
			if (flowerMode) saveFileDialog1.FileName += " (flower)";
			this.WindowState = WindowState.Minimized;
			if (saveFileDialog1.ShowDialog() == DialogResult.Cancel)
			{
				createMessage("CANCEL - FILE NOT SAVED", -1000f, -900f, 4f, 5000);
			}
			else
			{
				if (saveFileDialog1.FileName != "")
				{
					string output = generateTextFileContents(flowerMode);
					using (var txtFile = new StreamWriter(saveFileDialog1.FileName, false))
					{
						txtFile.Write(output);
						txtFile.Close();
					}
					createMessage("SAVED TO FILE - " + saveFileDialog1.FileName, -1000f, -900f, 2f, 8000);
				}
			}
			this.WindowState = WindowState.Normal;
		}

		private string generateTextFileContents(bool flowerMode)
		{
			string s = "# " + maxDots.ToString() + " Vertex Sphere - Generated by SphereDivision (Lift Pizzas)";
			s += "\r\n# Vertices:\r\n";
			//vertices

			if (flowerMode) s += "v 0 0 0\r\n"; //add a vertex at the origin for all faces to connect to

			for (var i = 0; i < maxDots; i++)
			{
				Vector3 t = p[i] / sphereRadius;
				s += "v " + t.X + " " + t.Y + " " + t.Z + "\r\n";
			}
			
			s += "\r\n# Faces:";

			triCount = 0;
			if (flowerMode)
			{
				for (var i = 0; i < maxDots; i++)
				{
					for (var j = i + 1; j < maxDots; j++)
					{
						//get distance from i to j
						if ((p[j] - p[i]).Length < minDist * 1.25f)
						{
							s += "f 1 " + (i + 2).ToString() + " " + (j + 2).ToString() + "\r\n";
							triCount++;
						}
					}
				}
			}
			else
			{ 
				// faces
				triListA = new int[maxDots * 3];
				triListB = new int[maxDots * 3];
				triListC = new int[maxDots * 3];
				for (int va = 0; va < maxDots; va++)
				{
					for (int vb = va + 1; vb < maxDots; vb++)
					{
						float dist = (p[vb] - p[va]).Length;
						if (dist < minDist * 1.25f)
						{
							for (int vc = vb + 1; vc < maxDots; vc++)
							{
								dist = (p[vb] - p[vc]).Length;
								if (dist < minDist * 1.25f)
								{
									dist = (p[va] - p[vc]).Length;
									if (dist < minDist * 1.25f)
									{
										//found a triangle
										s += "f " + (va + 1).ToString() + " " + (vb + 1).ToString() + " " + (vc + 1).ToString() + "\r\n";
										triCount++;
									}
								}
							}
						}

					}
				}
			}

			s += "# " + triCount.ToString() + " faces";
			return s;
		}

	}
}
